#Note
CheckersComputerPlayer contains 4 weight values as final variables that can be modified in order to adjust the 
priority of the algorithm